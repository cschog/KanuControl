package com.kcserver.entity;

import com.kcserver.audit.Auditable;
import com.kcserver.enumtype.TeilnehmerRolle;
import com.kcserver.persistence.converter.TeilnehmerRolleConverter;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(
        name = "teilnehmer",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_teilnehmer_veranstaltung_person",
                        columnNames = {"veranstaltung_id", "person_id"}
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Teilnehmer extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /* =========================
       Beziehungen
       ========================= */

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "veranstaltung_id", nullable = false)
    private Veranstaltung veranstaltung;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "person_id", nullable = false)
    private Person person;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "finanz_gruppe_id")
    private FinanzGruppe finanzGruppe;

    /* =========================
       Rolle in der Veranstaltung
       ========================= */

    @Convert(converter = TeilnehmerRolleConverter.class)
    @Column(length = 1)
    private TeilnehmerRolle rolle;

    @Column(name = "individueller_beitrag", precision = 10, scale = 2)
    private BigDecimal individuellerBeitrag;
}