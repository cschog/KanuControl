package com.kcserver.entity;

import com.kcserver.audit.Auditable;
import com.kcserver.enumtype.CountryCode;
import com.kcserver.enumtype.VeranstaltungScope;
import com.kcserver.enumtype.VeranstaltungTyp;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Entity
@Table(name = "veranstaltung")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Veranstaltung extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /* =========================
       Stammdaten
       ========================= */

    @Column(nullable = false, length = 200)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 3)
    private VeranstaltungTyp typ;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "unterkunftsart_id")
    private Unterkunftsart unterkunftsart;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "verpflegungsmodell_id")
    private Verpflegungsmodell verpflegungsmodell;


    @Column
    private String plz;

    @Column
    private String ort;

    @Column(name = "country_code", length = 2)
    private CountryCode countryCode;

    @Column(name = "beginn_datum", nullable = false)
    private LocalDate beginnDatum;

    @Column(name = "beginn_zeit", nullable = false)
    private LocalTime beginnZeit;

    @Column(name = "ende_datum", nullable = false)
    private LocalDate endeDatum;

    @Column(name = "ende_zeit", nullable = false)
    private LocalTime endeZeit;

    @Builder.Default
    @Column(name = "individuelle_gebuehren", nullable = false)
    private boolean individuelleGebuehren = false;

    @Column(name = "standard_gebuehr", precision = 10, scale = 2)
    private BigDecimal standardGebuehr;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private VeranstaltungScope scope;

    /* =========================
       Beziehungen
       ========================= */

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "verein_id", nullable = false)
    private Verein verein;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "leiter_id", nullable = false)
    private Person leiter;

    @ManyToOne
    @JoinColumn(name = "beitragsstruktur_id")
    private Beitragsstruktur beitragsstruktur;

    @OneToMany(
            mappedBy = "veranstaltung",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    private List<Zahlungsnachweis> zahlungsnachweise;

    /* =========================
       Status
       ========================= */

    @Column(nullable = false)
    private boolean aktiv;
}