package com.kcserver.service.veranstaltung;

import com.kcserver.api.response.ApiResponse;
import com.kcserver.dto.beitrag.BeitragsstrukturDTO;
import com.kcserver.dto.person.PersonListDTO;
import com.kcserver.dto.veranstaltung.*;
import com.kcserver.entity.*;
import com.kcserver.enumtype.TeilnehmerRolle;
import com.kcserver.enumtype.VeranstaltungTyp;
import com.kcserver.mapper.BeitragsstrukturMapper;
import com.kcserver.repository.VeranstaltungSpecs;

import com.kcserver.mapper.PersonMapper;
import com.kcserver.mapper.VeranstaltungMapper;
import com.kcserver.repository.*;
import com.kcserver.repository.abrechnung.AbrechnungRepository;
import com.kcserver.repository.abrechnung.ZahlungsnachweisRepository;
import com.kcserver.repository.beitrag.BeitragsstrukturRepository;
import com.kcserver.repository.fahrkosten.ReisekostenabrechnungRepository;
import com.kcserver.service.beitrag.BeitragsstrukturService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import static com.kcserver.exception.ErrorMessages.*;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import com.kcserver.service.finanz.FinanzGruppeService;

@Slf4j
@RequiredArgsConstructor
@Service
@Transactional
public class VeranstaltungServiceImpl implements VeranstaltungService {

    private final VeranstaltungRepository veranstaltungRepository;
    private final VereinRepository vereinRepository;
    private final PersonRepository personRepository;
    private final TeilnehmerRepository teilnehmerRepository;
    private final PlanungRepository planungRepository;
    private final VeranstaltungMapper veranstaltungMapper;
    private final PersonMapper personMapper;
    private final BeitragsstrukturService beitragsstrukturService;
    private final BeitragsstrukturMapper beitragsstrukturMapper;
    private final BeitragsstrukturRepository beitragsstrukturRepository;

    private final UnterkunftsartRepository unterkunftsartRepository;
    private final VerpflegungsmodellRepository verpflegungsmodellRepository;
    private final FinanzGruppeService finanzGruppeService;

    private final AbrechnungRepository abrechnungRepository;
    private final ZahlungsnachweisRepository zahlungsnachweisRepository;
    private final ReisekostenabrechnungRepository reisekostenabrechnungRepository;


    /* =========================================================
       CREATE
       ========================================================= */

    @Override
    public ApiResponse<VeranstaltungDetailDTO> create(
            VeranstaltungCreateDTO dto) {

        // =========================================================
        // 1. Zuerst alle Voraussetzungen prüfen
        // =========================================================

        Verein verein = vereinRepository.findById(dto.getVereinId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        VEREIN_NOT_FOUND
                ));

        Person leiter = personRepository.findById(dto.getLeiterId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        PERSON_NOT_FOUND
                ));

        validateLeiterAge(leiter);

        // =========================================================
        // 2. Erst wenn alle Voraussetzungen erfüllt sind:
        //    bisherige aktive Veranstaltung deaktivieren
        // =========================================================

        veranstaltungRepository.unsetAktiveVeranstaltung();
        veranstaltungRepository.flush();

        // =========================================================
        // 3. Veranstaltung erstellen
        // =========================================================

        Veranstaltung v = new Veranstaltung();
        v.setName(dto.getName());
        v.setTyp(dto.getTyp());
        v.setBeginnDatum(dto.getBeginnDatum());
        v.setEndeDatum(dto.getEndeDatum());
        v.setBeginnZeit(dto.getBeginnZeit());
        v.setEndeZeit(dto.getEndeZeit());
        v.setVerein(verein);
        v.setLeiter(leiter);
        v.setAktiv(true);

        List<String> warnings = adjustFmJemType(v);

        Veranstaltung saved = veranstaltungRepository.save(v);

        finanzGruppeService.getOrCreateVereinsFinanzGruppe(saved);

        Teilnehmer t = new Teilnehmer();
        t.setVeranstaltung(saved);
        t.setPerson(leiter);
        t.setRolle(TeilnehmerRolle.LEITER);
        teilnehmerRepository.save(t);

        Veranstaltung loaded = veranstaltungRepository
                .findByIdWithRelations(saved.getId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        VERANSTALTUNG_NOT_FOUND
                ));

        VeranstaltungDetailDTO dtoResult =
                veranstaltungMapper.toDetailDTO(loaded);

        return new ApiResponse<>(dtoResult, warnings);
    }

    /* =========================================================
       READ
       ========================================================= */

    @Override
    @Transactional(readOnly = true)
    public VeranstaltungDetailDTO getById(Long id) {
        return veranstaltungMapper.toDetailDTO(
                veranstaltungRepository.findByIdWithRelations(id)
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND))
        );
    }

    @Override
    @Transactional(readOnly = true)
    public List<VeranstaltungListDTO> getAll() {
        return veranstaltungRepository.findAll()
                .stream()
                .map(veranstaltungMapper::toListDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Page<VeranstaltungListDTO> search(
            VeranstaltungFilterDTO filter,
            Pageable pageable
    ) {
        return veranstaltungRepository.findAll(
                VeranstaltungSpecs.filter(filter),
                pageable
        ).map(veranstaltungMapper::toListDTO);
    }

    /* =========================================================
       AVAILABLE / ASSIGNED
       ========================================================= */

    @Override
    @Transactional(readOnly = true)
    public List<PersonListDTO> getAvailablePersons(Long veranstaltungId, String search) {

        checkVeranstaltungExists(veranstaltungId);

        String searchTerm = (search == null || search.isBlank()) ? "" : search.trim();

        return teilnehmerRepository
                .findAvailable(veranstaltungId, safe(searchTerm))
                .stream()
                .map(personMapper::toListDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<PersonListDTO> getAssignedPersons(Long veranstaltungId) {

        return teilnehmerRepository
                .findAllWithPerson(veranstaltungId)
                .stream()
                .map(t -> personMapper.toListDTO(t.getPerson()))
                .toList();
    }


    @Transactional(readOnly = true)
    public List<VeranstaltungListDTO> searchAll(
            VeranstaltungFilterDTO filter
    ) {
        return veranstaltungRepository.findAll(
                        VeranstaltungSpecs.filter(filter)
                )
                .stream()
                .map(veranstaltungMapper::toListDTO)
                .toList();
    }

    /* =========================================================
       BULK
       ========================================================= */

    @Override
    public void addTeilnehmerBulk(Long veranstaltungId, List<Long> personIds) {

        Veranstaltung v = getVeranstaltungOrThrow(veranstaltungId);

        List<Person> persons = personRepository.findAllById(personIds);

        for (Person p : persons) {

            boolean exists = teilnehmerRepository
                    .findByVeranstaltungAndPerson(v, p)
                    .isPresent();

            if (!exists) {
                Teilnehmer t = new Teilnehmer();
                t.setVeranstaltung(v);
                t.setPerson(p);
                teilnehmerRepository.save(t);
            }
        }
    }

    @Override
    public void removeTeilnehmerBulk(Long veranstaltungId, List<Long> personIds) {

        Veranstaltung v = getVeranstaltungOrThrow(veranstaltungId);

        for (Long personId : personIds) {

            if (personIds.isEmpty()) return;

            Person p = personRepository.findById(personId)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

            teilnehmerRepository
                    .findByVeranstaltungAndPerson(v, p)
                    .ifPresent(t -> {

                        if (t.getRolle() == TeilnehmerRolle.LEITER) {
                            throw new ResponseStatusException(HttpStatus.CONFLICT);
                        }

                        teilnehmerRepository.delete(t);
                    });
        }
    }

    /* =========================================================
       DELETE
       ========================================================= */

    @Override
    public void delete(Long id) {

        Veranstaltung v = getVeranstaltungOrThrow(id);
        boolean warAktiv = v.isAktiv();

        // =========================================================
        // 1. Teilnehmer prüfen
        // =========================================================

        boolean hasTeilnehmer =
                teilnehmerRepository.existsNonLeiter(id, TeilnehmerRolle.LEITER);

        if (hasTeilnehmer) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Die Veranstaltung kann nicht gelöscht werden, solange weitere Teilnehmer vorhanden sind."
            );
        }

        // =========================================================
        // 2. Zahlungsnachweise löschen
        //
        //    Cascade:
        //    Zahlungspositionen
        //    Dokumente
        // =========================================================

        List<Zahlungsnachweis> zahlungsnachweise =
                zahlungsnachweisRepository
                        .findByVeranstaltungIdOrderByDatumDescIdDesc(id);

        zahlungsnachweisRepository.deleteAll(zahlungsnachweise);

        // =========================================================
        // 3. Abrechnung löschen
        //
        //    Cascade:
        //    AbrechnungBeleg
        //    AbrechnungBuchung
        //    Dokument
        //
        //    Wichtig:
        //    Dadurch verschwinden auch Referenzen von
        //    AbrechnungBuchung → Reisekostenabrechnung
        // =========================================================

        abrechnungRepository.findByVeranstaltungId(id)
                .ifPresent(abrechnungRepository::delete);

        // =========================================================
        // 4. Reisekostenabrechnungen löschen
        //
        //    Cascade:
        //    Fahrtabschnitt
        //    FahrtabschnittMitfahrer
        // =========================================================

        List<Reisekostenabrechnung> reisekosten =
                reisekostenabrechnungRepository
                        .findByVeranstaltungId(id);

        reisekostenabrechnungRepository.deleteAll(reisekosten);

        // =========================================================
        // 5. Planung löschen
        //
        //    Cascade:
        //    PlanungPosition
        // =========================================================

        planungRepository.findByVeranstaltungId(id)
                .ifPresent(planungRepository::delete);

        // =========================================================
        // 6. Teilnehmer löschen
        // =========================================================

        teilnehmerRepository.deleteByVeranstaltungId(id);

        // =========================================================
        // 7. Finanzgruppen löschen
        // =========================================================

        finanzGruppeService.deleteByVeranstaltungId(id);

        // =========================================================
        // 8. Veranstaltung löschen
        // =========================================================

        veranstaltungRepository.delete(v);
        veranstaltungRepository.flush();

        // =========================================================
        // 9. Falls aktive Veranstaltung gelöscht wurde:
        //    neueste Veranstaltung aktiv setzen
        // =========================================================

        if (warAktiv) {

            Optional<Veranstaltung> neuAktiv =
                    veranstaltungRepository
                            .findTopByIdNotOrderByBeginnDatumDescBeginnZeitDesc(id);

            neuAktiv.ifPresent(veranstaltung -> {
                veranstaltung.setAktiv(true);
                veranstaltungRepository.save(veranstaltung);
            });
        }
    }

    @Override
    @Transactional
    public BeitragsstrukturDTO assignBeitragsstrukturFromTemplate(
            Long veranstaltungId,
            Long templateId
    ) {

        Veranstaltung veranstaltung =
                veranstaltungRepository.findById(veranstaltungId)
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        if (veranstaltung.getBeitragsstruktur() != null) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Veranstaltung hat bereits eine Beitragsstruktur"
            );
        }

        Beitragsstruktur struktur =
                beitragsstrukturService.copyFromTemplateEntity(
                        templateId,
                        "Beitragsstruktur " + veranstaltung.getName()
                );
        veranstaltung.setBeitragsstruktur(struktur);

        veranstaltungRepository.save(veranstaltung);

        return beitragsstrukturMapper.toDTO(struktur);

    }



    /* =========================================================
       HELPER
       ========================================================= */

    private Veranstaltung getVeranstaltungOrThrow(Long id) {
        return veranstaltungRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    private void checkVeranstaltungExists(Long id) {
        if (!veranstaltungRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
    }

    private String safe(String s) {
        return s == null ? "" : s;
    }

    private void validateLeiterAge(Person person) {
        if (person.getGeburtsdatum() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Für den Veranstaltungsleiter muss ein Geburtsdatum hinterlegt sein."
            );
        }

        if (person.getGeburtsdatum().plusYears(18).isAfter(LocalDate.now())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Der Veranstaltungsleiter muss mindestens 18 Jahre alt sein."
            );
        }
    }
    @Override
    @Transactional(readOnly = true)
    public VeranstaltungDetailDTO getActive() {
        return veranstaltungRepository.findByAktivTrue()
                .map(veranstaltungMapper::toDetailDTO)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "No active Veranstaltung"
                ));
    }
    @Override
    @Transactional(readOnly = true)
    public Optional<VeranstaltungDetailDTO> getActiveOptional() {
        return veranstaltungRepository.findByAktivTrue()
                .map(veranstaltungMapper::toDetailDTO);
    }

    @Override
    public VeranstaltungDetailDTO setActive(Long veranstaltungId) {

        Veranstaltung neu = veranstaltungRepository.findById(veranstaltungId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        // alle deaktivieren
        veranstaltungRepository.unsetAktiveVeranstaltung();
        veranstaltungRepository.flush();

        // aktiv setzen
        neu.setAktiv(true);
        veranstaltungRepository.save(neu);

        // 🔥 ENTSCHEIDEND: neu laden mit JOIN FETCH
        Veranstaltung loaded = veranstaltungRepository
                .findByIdWithRelations(neu.getId())
                .orElseThrow();

        return veranstaltungMapper.toDetailDTO(loaded);
    }


    @Transactional
    @Override
    public ApiResponse<VeranstaltungDetailDTO> update(
            Long id,
            VeranstaltungUpdateDTO dto) {

        Veranstaltung v = veranstaltungRepository.findByIdWithRelations(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, VERANSTALTUNG_NOT_FOUND
                ));

    /* =========================
       SIMPLE FIELDS
       ========================= */

        if (dto.getName() != null) {
            v.setName(dto.getName());
        }

        if (dto.getTyp() != null) {
            v.setTyp(dto.getTyp());
        }

        if (dto.getBeginnDatum() != null) {
            v.setBeginnDatum(dto.getBeginnDatum());
        }

        if (dto.getEndeDatum() != null) {
            v.setEndeDatum(dto.getEndeDatum());
        }

        if (dto.getBeginnZeit() != null) {
            v.setBeginnZeit(dto.getBeginnZeit());
        }

        if (dto.getEndeZeit() != null) {
            v.setEndeZeit(dto.getEndeZeit());
        }

    /* =========================
       VEREIN
       ========================= */

        if (dto.getVereinId() != null) {

            Verein verein = vereinRepository.findById(dto.getVereinId())
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.NOT_FOUND, VEREIN_NOT_FOUND
                    ));

            v.setVerein(verein);
        }

    /* =========================
       LEITER (inkl. Validierung)
       ========================= */

        if (dto.getLeiterId() != null) {

            Person leiter = personRepository.findById(dto.getLeiterId())
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.NOT_FOUND, PERSON_NOT_FOUND
                    ));

            validateLeiterAge(leiter);

            v.setLeiter(leiter);
        }

        /* =========================
   DETAILFELDER
   ========================= */

        v.setCountryCode(dto.getCountryCode());
        v.setPlz(dto.getPlz());
        v.setOrt(dto.getOrt());

        v.setUnterkunftsart(
                getUnterkunftsart(dto.getUnterkunftsartId()));

        v.setVerpflegungsmodell(
                getVerpflegungsmodell(dto.getVerpflegungsmodellId()));

/* =========================
   GEBÜHREN
   ========================= */

        if (dto.getIndividuelleGebuehren() != null) {
            v.setIndividuelleGebuehren(dto.getIndividuelleGebuehren());
        }

/* =========================
   BEITRAGSSTRUKTUR
   ========================= */

        if (dto.getBeitragsstrukturId() != null) {

            Beitragsstruktur struktur =
                    beitragsstrukturRepository
                            .findById(dto.getBeitragsstrukturId())
                            .orElseThrow(() ->
                                    new EntityNotFoundException(
                                            "Beitragsstruktur nicht gefunden"
                                    )
                            );

            v.setBeitragsstruktur(struktur);
        }

/* =========================================
   VALIDIERUNG INDIVIDUELLE GEBÜHREN
   ========================================= */

        if (v.isIndividuelleGebuehren()) {


            // Struktur zwingend erforderlich
            if (v.getBeitragsstruktur() == null) {

                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Für individuelle Gebühren muss eine Beitragsstruktur gewählt werden."
                );
            }

        } else {

            // Nur bei NICHT individuellen Gebühren setzen
            v.setStandardGebuehr(dto.getStandardGebuehr());
        }

        if (dto.getScope() != null) {
            v.setScope(dto.getScope());
        }

        List<String> warnings = adjustFmJemType(v);

        Veranstaltung saved = veranstaltungRepository.save(v);

        finanzGruppeService.getOrCreateVereinsFinanzGruppe(saved);

        VeranstaltungDetailDTO dtoResult =
                veranstaltungMapper.toDetailDTO(saved);

        return new ApiResponse<>(dtoResult, warnings);
    }

    @Override
    @Transactional(readOnly = true)
    public Veranstaltung findEntityById(Long id) {

        return veranstaltungRepository
                .findByIdWithRelations(id)
                .orElseThrow(() ->
                        new EntityNotFoundException(
                                VERANSTALTUNG_NOT_FOUND
                        )
                );
    }

    private List<String> adjustFmJemType(Veranstaltung veranstaltung) {
        List<String> warnings = new ArrayList<>();

        if (veranstaltung.getTyp() != VeranstaltungTyp.FM
                && veranstaltung.getTyp() != VeranstaltungTyp.JEM) {
            return warnings;
        }

        if (veranstaltung.getBeginnDatum() == null || veranstaltung.getEndeDatum() == null) {
            return warnings;
        }

        long dauerInTagen = ChronoUnit.DAYS.between(
                veranstaltung.getBeginnDatum(),
                veranstaltung.getEndeDatum()
        ) + 1;

        if (dauerInTagen <= 0) {
            warnings.add(
                    "Das Enddatum liegt vor dem Beginndatum."
            );
            return warnings;
        }

        if (dauerInTagen <= 4) {
            veranstaltung.setTyp(VeranstaltungTyp.FM);
        } else {
            veranstaltung.setTyp(VeranstaltungTyp.JEM);

            if (dauerInTagen > 21) {
                warnings.add(
                        "Die Veranstaltung dauert " + dauerInTagen
                                + " Tage. FM/JEM-Veranstaltungen dürfen maximal 21 Tage dauern." +
                                "Für die Förderung werden 21 Tage berücksichtigt."
                );
            }
        }



        return warnings;
    }
    private Unterkunftsart getUnterkunftsart(Long id) {

        if (id == null) {
            return null;
        }

        return unterkunftsartRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        UNTERKUNFTSART_NOT_FOUND
                ));
    }

    private Verpflegungsmodell getVerpflegungsmodell(Long id) {

        if (id == null) {
            return null;
        }

        return verpflegungsmodellRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        VERPFLEGUNGSMODELL_NOT_FOUND
                ));
    }
}