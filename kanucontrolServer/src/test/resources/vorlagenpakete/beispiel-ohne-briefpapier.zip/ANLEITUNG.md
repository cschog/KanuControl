# Synthetisches Beispiel
Kein Briefpapier enthalten: Zielabschluss bleibt erhalten.
