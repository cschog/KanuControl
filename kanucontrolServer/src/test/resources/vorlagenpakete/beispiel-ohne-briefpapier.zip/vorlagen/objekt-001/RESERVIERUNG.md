```kanucontrol-template
{
  "formatVersion": 1,
  "anrede": "Hallo {{vorname}},",
  "betreff": "{{buchungsnummer}} – Reservierung",
  "bloecke": [
    {
      "id": "b01",
      "titel": "Aufenthalt",
      "bedingung": "IMMER",
      "varianten": [
        {
          "id": "v01",
          "bedingung": "KAUTION_POSITIV"
        }
      ]
    }
  ]
}
```

<!-- kc:mailtext -->
Hallo {{vorname}},

bitte prüft die Reservierung im Anhang.
<!-- kc:end -->

<!-- kc:block b01 -->
Wir begrüßen euch vom {{anreise}} bis {{abreise}} in {{mietobjekt}}.
<!-- kc:end -->

<!-- kc:variante b01 v01 -->
Die Kaution beträgt {{kaution}} €.
<!-- kc:end -->
