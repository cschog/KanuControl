```kanucontrol-template
{
  "formatVersion": 1,
  "anrede": "Hallo {{vorname}} {{nachname}},",
  "betreff": "{{buchungsnummer}} – Reservierungsbestätigung Bootshaus",
  "bloecke": [
    {
      "id": "b1",
      "titel": "Reservierung",
      "bedingung": "IMMER",
      "varianten": []
    },
    {
      "id": "b2",
      "titel": "Miete",
      "bedingung": "IMMER",
      "varianten": []
    },
    {
      "id": "b3",
      "titel": "Zahlungsplan",
      "bedingung": "IMMER",
      "varianten": [
        {
          "id": "v1",
          "bedingung": "ANZAHLUNG_POSITIV"
        },
        {
          "id": "v2",
          "bedingung": "RESTMIETE_POSITIV"
        },
        {
          "id": "v3",
          "bedingung": "ZAHLUNG_GESAMTMIETE_VORAUS"
        },
        {
          "id": "v4",
          "bedingung": "ZAHLUNG_BEI_ABRECHNUNG"
        },
        {
          "id": "v5",
          "bedingung": "KAUTION_POSITIV"
        }
      ]
    },
    {
      "id": "b4",
      "titel": "Konto und Hinweise",
      "bedingung": "IMMER",
      "varianten": []
    },
    {
      "id": "b5",
      "titel": "Stornoregel",
      "bedingung": "IMMER",
      "varianten": []
    }
  ]
}
```

<!-- kc:mailtext -->
Hallo {{vorname}} {{nachname}},

im Anhang findet ihr unser Schreiben zur Buchung {{buchungsnummer}}: Reservierungsbestätigung.

Mit freundlichen Grüßen
Eschweiler Kanu Club e.V.
Fachbereich Bootshaus
<!-- kc:end -->

<!-- kc:block b1 -->
Vielen Dank für eure Anfrage. Wir reservieren euch das Bootshaus vom {{anreise}} bis {{abreise}}. Bitte gebt bei Rückfragen und Überweisungen die Buchungsnummer {{buchungsnummer}} an.
<!-- kc:end -->

<!-- kc:block b2 -->
Die vereinbarte Miete beträgt {{mietbetrag}} €.
<!-- kc:end -->

<!-- kc:block b3 -->

<!-- kc:end -->

<!-- kc:variante b3 v1 -->
Bitte überweist die Anzahlung von {{anzahlung}} €.
<!-- kc:end -->

<!-- kc:variante b3 v2 -->
Die verbleibende Miete von {{restmiete}} € ist bis zum {{zahlungsfrist}} zu überweisen.
<!-- kc:end -->

<!-- kc:variante b3 v3 -->
Bitte überweist die Gesamtmiete von {{mietbetrag}} € im Voraus bis zum {{zahlungsfrist}}.
<!-- kc:end -->

<!-- kc:variante b3 v4 -->
Die Miete wird nach dem Aufenthalt gemeinsam mit Verbrauchskosten und Zusatzleistungen abgerechnet. Eine Mietvorauszahlung ist nicht vorgesehen.
<!-- kc:end -->

<!-- kc:variante b3 v5 -->
Bitte überweist die Kaution von {{kaution}} € bis zum {{zahlungsfrist}}.
<!-- kc:end -->

<!-- kc:block b4 -->
Für vereinbarte Vorauszahlungen und Kaution verwendet bitte das auf diesem Schreiben angegebene Vereinskonto. Verbrauchskosten und tatsächlich genutzte Zusatzleistungen werden in der Schlussabrechnung berücksichtigt. Bitte beachtet die Hausregeln: {{hausregeln_url}}
<!-- kc:end -->

<!-- kc:block b5 -->
Bei Stornierung ab einschließlich 56 Tagen vor Mietbeginn werden alle geleisteten Zahlungen erstattet. Bei Stornierung weniger als 56 Tage vor Mietbeginn erfolgt keine Erstattung.
<!-- kc:end -->

