```kanucontrol-template
{
  "formatVersion": 1,
  "anrede": "Hallo {{vorname}} {{nachname}},",
  "betreff": "{{buchungsnummer}} – Schlussabrechnung Bootshaus",
  "bloecke": [
    {
      "id": "b1",
      "titel": "Einleitung",
      "bedingung": "IMMER",
      "varianten": []
    },
    {
      "id": "b2",
      "titel": "Restzahlung",
      "bedingung": "RESTZAHLUNG_POSITIV",
      "varianten": []
    },
    {
      "id": "b3",
      "titel": "Rückerstattung",
      "bedingung": "ERSTATTUNG_POSITIV",
      "varianten": []
    },
    {
      "id": "b4",
      "titel": "Ausgeglichen",
      "bedingung": "AUSGEGLICHEN",
      "varianten": []
    },
    {
      "id": "b5",
      "titel": "Abschluss",
      "bedingung": "IMMER",
      "varianten": []
    }
  ]
}
```

<!-- kc:mailtext -->
Hallo {{vorname}} {{nachname}},

im Anhang findet ihr unser Schreiben zur Buchung {{buchungsnummer}}: Schlussabrechnung.

Mit freundlichen Grüßen
Eschweiler Kanu Club e.V.
Fachbereich Bootshaus
<!-- kc:end -->

<!-- kc:block b1 -->
Für euren Aufenthalt im Bootshaus vom {{anreise}} bis {{abreise}} ergibt sich folgende Abrechnung. Die Tabelle enthält Kosten und bereits erfasste Zahlungen.
<!-- kc:end -->

<!-- kc:block b2 -->
Bitte überweist die noch offene Restzahlung von {{restzahlung}} € bis zum {{zahlungsfrist}} auf das Vereinskonto.
Bank: {{bank_name}}
IBAN: {{bank_iban}}
BIC: {{bank_bic}}
Verwendungszweck: {{buchungsnummer}}
<!-- kc:end -->

<!-- kc:block b3 -->
Die Rückerstattung von {{erstattung}} € überweisen wir in den nächsten Tagen auf folgendes Konto:
Bank: {{mieter_bank_name}}
IBAN: {{mieter_bank_iban}}
BIC: {{mieter_bank_bic}}
Kontoinhaber: {{mieter_kontoinhaber}}
<!-- kc:end -->

<!-- kc:block b4 -->
Die Abrechnung ist ausgeglichen. Es ist keine weitere Zahlung erforderlich.
<!-- kc:end -->

<!-- kc:block b5 -->
Vielen Dank für euren Besuch. Bei Rückfragen nennt bitte die Buchungsnummer {{buchungsnummer}}.
<!-- kc:end -->

