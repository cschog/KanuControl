```kanucontrol-template
{
  "formatVersion": 1,
  "anrede": "Hallo {{vorname}} {{nachname}},",
  "betreff": "{{buchungsnummer}} – Rückmeldung zu eurer Buchungsanfrage Bootshaus",
  "bloecke": [
    {
      "id": "b1",
      "titel": "Rückmeldung",
      "bedingung": "IMMER",
      "varianten": []
    },
    {
      "id": "b2",
      "titel": "Alternative",
      "bedingung": "IMMER",
      "varianten": []
    }
  ]
}
```

<!-- kc:mailtext -->
Hallo {{vorname}} {{nachname}},

im Anhang findet ihr unser Schreiben zur Buchung {{buchungsnummer}}: Rückmeldung zu eurer Buchungsanfrage.

Mit freundlichen Grüßen
Eschweiler Kanu Club e.V.
Fachbereich Bootshaus
<!-- kc:end -->

<!-- kc:block b1 -->
Vielen Dank für eure Anfrage für das Bootshaus vom {{anreise}} bis {{abreise}}. Leider können wir diese Anfrage nicht bestätigen.
<!-- kc:end -->

<!-- kc:block b2 -->
Wenn ihr einen anderen Zeitraum in Betracht zieht, meldet euch gerne erneut bei uns. Vielen Dank für euer Verständnis.
<!-- kc:end -->

