```kanucontrol-template
{
  "formatVersion": 1,
  "anrede": "Hallo {{vorname}} {{nachname}},",
  "betreff": "{{buchungsnummer}} – Vorbereitung der Schlussabrechnung Bootshaus",
  "bloecke": [
    {
      "id": "b1",
      "titel": "Aufenthalt",
      "bedingung": "IMMER",
      "varianten": []
    },
    {
      "id": "b2",
      "titel": "Abrechnung",
      "bedingung": "IMMER",
      "varianten": []
    },
    {
      "id": "b3",
      "titel": "Rückfragen",
      "bedingung": "IMMER",
      "varianten": []
    }
  ]
}
```

<!-- kc:mailtext -->
Hallo {{vorname}} {{nachname}},

im Anhang findet ihr unser Schreiben zur Buchung {{buchungsnummer}}: Vorbereitung der Schlussabrechnung.

Mit freundlichen Grüßen
Eschweiler Kanu Club e.V.
Fachbereich Bootshaus
<!-- kc:end -->

<!-- kc:block b1 -->
Wir hoffen, ihr hattet einen schönen Aufenthalt im Bootshaus vom {{anreise}} bis {{abreise}}.
<!-- kc:end -->

<!-- kc:block b2 -->
Wir bereiten die Schlussabrechnung vor. Darin berücksichtigen wir die vereinbarte Miete, Verbrauchskosten, Zusatzleistungen und die tatsächlich erfassten Zahlungen. Bitte wartet die Schlussabrechnung ab; dieses Schreiben ist keine Zahlungsaufforderung.
<!-- kc:end -->

<!-- kc:block b3 -->
Bitte gebt bei Rückfragen die Buchungsnummer {{buchungsnummer}} an.
<!-- kc:end -->

