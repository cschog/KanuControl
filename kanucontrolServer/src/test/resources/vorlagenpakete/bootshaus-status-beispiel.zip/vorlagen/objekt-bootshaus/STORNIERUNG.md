```kanucontrol-template
{
  "formatVersion": 1,
  "anrede": "Hallo {{vorname}} {{nachname}},",
  "betreff": "{{buchungsnummer}} – Stornierungsbestätigung Bootshaus",
  "bloecke": [
    {
      "id": "b1",
      "titel": "Stornierung",
      "bedingung": "IMMER",
      "varianten": []
    },
    {
      "id": "b2",
      "titel": "Erstattung",
      "bedingung": "STORNO_ERSTATTUNG_POSITIV",
      "varianten": []
    },
    {
      "id": "b3",
      "titel": "Einbehalt",
      "bedingung": "STORNO_EINBEHALT_POSITIV",
      "varianten": []
    },
    {
      "id": "b4",
      "titel": "Keine offene Erstattung",
      "bedingung": "STORNO_OHNE_ZAHLUNG",
      "varianten": []
    },
    {
      "id": "b5",
      "titel": "Abschluss",
      "bedingung": "IMMER",
      "varianten": []
    }
  ]
}
```

<!-- kc:mailtext -->
Hallo {{vorname}} {{nachname}},

im Anhang findet ihr unser Schreiben zur Buchung {{buchungsnummer}}: Stornierungsbestätigung.

Mit freundlichen Grüßen
Eschweiler Kanu Club e.V.
Fachbereich Bootshaus
<!-- kc:end -->

<!-- kc:block b1 -->
Wir bestätigen die Stornierung eurer Buchung {{buchungsnummer}} am {{stornodatum}} für den geplanten Aufenthalt vom {{anreise}} bis {{abreise}}.
<!-- kc:end -->

<!-- kc:block b2 -->
Da die Stornierung mindestens 56 Tage vor Mietbeginn erfolgt, werden alle geleisteten Zahlungen zurückerstattet. Insgesamt gezahlt: {{storno_gezahlter_betrag}} €. Bereits erstattet: {{storno_bereits_erstattet}} €. Noch zu erstatten: {{storno_erstattung}} €.
Wir überweisen auf folgendes Konto:
Bank: {{mieter_bank_name}}
IBAN: {{mieter_bank_iban}}
BIC: {{mieter_bank_bic}}
Kontoinhaber: {{mieter_kontoinhaber}}
<!-- kc:end -->

<!-- kc:block b3 -->
Die Stornierung erfolgt weniger als 56 Tage vor Mietbeginn. Nach der vereinbarten Stornoregel werden die geleisteten Zahlungen nicht erstattet. Der Einbehalt beträgt {{storno_einbehalt}} €.
<!-- kc:end -->

<!-- kc:block b4 -->
Aus den erfassten Zahlungen ergibt sich kein noch zu erstattender Betrag.
<!-- kc:end -->

<!-- kc:block b5 -->
Bei Rückfragen gebt bitte die Buchungsnummer {{buchungsnummer}} an.
<!-- kc:end -->

