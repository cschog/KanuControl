```kanucontrol-template
{
  "formatVersion": 1,
  "anrede": "Hallo {{vorname}} {{nachname}},",
  "betreff": "{{buchungsnummer}} – Buchungsbestätigung Bootshaus",
  "bloecke": [
    {
      "id": "b1",
      "titel": "Bestätigung",
      "bedingung": "IMMER",
      "varianten": []
    },
    {
      "id": "b2",
      "titel": "Abrechnung",
      "bedingung": "IMMER",
      "varianten": []
    },
    {
      "id": "b3",
      "titel": "Vorbereitung",
      "bedingung": "IMMER",
      "varianten": []
    }
  ]
}
```

<!-- kc:mailtext -->
Hallo {{vorname}} {{nachname}},

im Anhang findet ihr unser Schreiben zur Buchung {{buchungsnummer}}: Buchungsbestätigung.

Mit freundlichen Grüßen
Eschweiler Kanu Club e.V.
Fachbereich Bootshaus
<!-- kc:end -->

<!-- kc:block b1 -->
Wir bestätigen eure Buchung des Bootshauses vom {{anreise}} bis {{abreise}} unter der Buchungsnummer {{buchungsnummer}}.
<!-- kc:end -->

<!-- kc:block b2 -->
Die Miete wird nach eurem Aufenthalt gemeinsam mit Verbrauchskosten und Zusatzleistungen abgerechnet. Diese Bestätigung enthält keine Zahlungsaufforderung.
<!-- kc:end -->

<!-- kc:block b3 -->
Bitte stimmt Anreise und Schlüsselübergabe rechtzeitig mit uns ab. Wir freuen uns auf euren Besuch.
<!-- kc:end -->

