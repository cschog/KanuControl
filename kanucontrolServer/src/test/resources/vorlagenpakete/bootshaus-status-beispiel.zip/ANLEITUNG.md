# Beispielvorlagen Bootshaus – Zielobjekt DB-ID 1

Dieses Paket enthält sechs Beispielvorlagen im KanuControl-Paketformat 1.
Beim Import „Bootshaus“ ausdrücklich dem Zielobjekt Bootshaus mit DB-ID 1 zuordnen.
Paketinterne Schlüssel sind keine Datenbank-IDs; die Zuordnung erfolgt im Importdialog.

1. Vermietung → Verwaltung → E-Mail- und PDF-Vorlagen → Vorlagen aus ZIP importieren.
2. Bootshaus dem Zielobjekt mit DB-ID 1 zuordnen.
3. Je Vorlage Neu, Vorhandene ausdrücklich ersetzen oder Überspringen auswählen.
4. Zuordnung, Inhalte und PDF-Vorschauen prüfen; erst dann übernehmen.

Das Paket enthält kein Briefpapier, keine Grußformel und kein Unterschriftsbild.
Die vorhandene gemeinsame Briefpapier-Konfiguration bleibt erhalten und muss eingerichtet sein.
Die PDF-Grußformel stammt weiterhin aus dieser Konfiguration.

Voraussetzung: installierter Stand mit Zahlungsvarianten und Abrechnungsvorlagen
(einschließlich Migration 20261111-01-abrechnung-vorlagen.xml).
Reservierung berücksichtigt Anzahlung, Zahlung bei Abrechnung oder Gesamtmiete im Voraus;
Kaution wird nur bei positivem Betrag angefordert. Die Zahlungsvariante wird an der Buchung gewählt.
Die Schlussabrechnung zeigt ausschließlich den zum Saldo passenden Zahlungstext.
Die Abrechnungstabelle wird automatisch nach der unbedingten Einleitung eingefügt.
Für Erstattungen Mieterbankdaten und gegebenenfalls abweichenden Kontoinhaber pflegen.

BESTAETIGUNG, STORNIERUNG, ABLEHNUNG und ABRECHENBAR sind mit enthaltene Textentwürfe.
Die neue Nachrichtenvorschau verwendet RESERVIERUNG, BESTAETIGUNG, ABLEHNUNG, STORNIERUNG und ABGERECHNET.
ABRECHENBAR ist ein Textentwurf und wird beim automatischen Statuswechsel nach Mietende nicht versendet.
RESERVIERT → BESTAETIGT erfolgt nach Zahlungseingang ohne Mail.
Voraussetzung zusätzlich: Migration 20261111-02-buchungsnachrichten.xml und zugehöriger Programmstand.

Die Stornotexte entsprechen der ausdrücklich vorgegebenen Regel: unter 56 Tagen keine Erstattung; ab 56 Tagen einschließlich alles zurück, abzüglich bereits erfolgter Rückzahlungen.
Vereinbarungen, Ansprechpartner und praktische Abläufe vor Verwendung fachlich prüfen.
Die Muster enthalten keine persönlichen Bankdaten aus der Beispielrechnung.
