# Über KanuControl

## KanuControl

KanuControl ist eine Software zur Verwaltung von Kanuvereinen und Vereinsveranstaltungen.

Die wesentliche Zielsetzung von KanuControl ist die Unterstützung von Vereinen bei der Planung, Beantragung, Durchführung und Abrechnung von geförderten Jugendmaßnahmen.

Hierzu werden alle relevanten Informationen zu Personen, Vereinen, Veranstaltungen, Teilnehmern, Beiträgen und Reisekosten zentral verwaltet und für die spätere Zuschussbeantragung aufbereitet.

## Funktionen

KanuControl unterstützt unter anderem:

- Planung und Verwaltung von Jugendmaßnahmen
- Ermittlung förderfähiger Teilnehmer
- Unterstützung bei Zuschussanträgen und Verwendungsnachweisen
- Reisekostenabrechnungen
- Teilnehmerverwaltung
- Personen- und Mitgliederverwaltung
- Vereinsverwaltung
- Finanz- und Beitragsverwaltung
- Mehrmandantenbetrieb für mehrere Vereine

## Zielsetzung

Viele Vereinsaufgaben werden noch mit Tabellenkalkulationen, Papierformularen oder verschiedenen Einzellösungen durchgeführt.

KanuControl verfolgt das Ziel, diese Prozesse in einer zentralen Anwendung zusammenzuführen und den Verwaltungsaufwand für Vereine zu reduzieren.

## Technologie

KanuControl basiert auf modernen Open-Source-Technologien:

- React
- TypeScript
- Spring Boot
- PostgreSQL
- Keycloak
- Liquibase

## Datenschutz und Sicherheit

KanuControl ist mandantenfähig aufgebaut.

Jeder Verein wird in einem eigenen Datenbankschema verwaltet. Die Benutzeranmeldung erfolgt über einen zentralen Authentifizierungsdienst. Die Kommunikation erfolgt verschlüsselt über HTTPS.

Zur Sicherstellung der Verfügbarkeit werden tägliche Datensicherungen erstellt.

## Entwicklung

KanuControl wird kontinuierlich weiterentwickelt.

Anregungen, Fehlerberichte und Verbesserungsvorschläge sind jederzeit willkommen.

## Version

Frontend: V1.0.1
Backend: V1.0.1
Datenbankschema: Version 73

## Kontakt

Chris Schog

Deutschland

---

© KanuControl