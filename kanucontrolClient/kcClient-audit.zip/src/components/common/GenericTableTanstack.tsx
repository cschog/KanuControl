import React from "react";
import { Row } from "@tanstack/react-table";
import EmptyState from "@/components/common/EmptyState";
import Collapse from "@mui/material/Collapse";
import { KeyboardArrowRight, KeyboardArrowDown } from "@mui/icons-material";

import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  RowSelectionState,
  SortingState,
  useReactTable,
} from "@tanstack/react-table";

import {
  Box,
  Checkbox,
  CircularProgress,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  useMediaQuery,
} from "@mui/material";

import { useTheme } from "@mui/material/styles";

export interface WithId {
  id: number;
}

interface GenericTableTanstackProps<T extends WithId> {
  data: T[];
  columns: ColumnDef<T>[];
  loading?: boolean;
  mobileRenderRow?: (row: T) => React.ReactNode;
  selectedRowId?: number | null;
  onSelectRow?: (row: T) => void;
  onRowSelectionChange?: (rows: T[]) => void;
  height?: number | string;
  enableCheckboxSelection?: boolean;
  resetSelectionTrigger?: number;
  fixedColumnWidths?: boolean;
  emptyState?: React.ReactNode;
  detailPanel?: (row: T) => React.ReactNode;

  // ⭐ SERVER SORTING
  sorting?: SortingState;

  onSortingChange?: (sorting: SortingState) => void;

  // ⭐ INFINITE SCROLL
  onLoadMore?: () => void;
  hasMore?: boolean;
}

export function GenericTableTanstack<T extends WithId>({
  data,
  columns,
  loading = false,
  selectedRowId,
  onSelectRow,
  onRowSelectionChange,
  height,
  sorting = [],
  onSortingChange,
  onLoadMore,
  hasMore = false,
  mobileRenderRow,
  resetSelectionTrigger,
  fixedColumnWidths = true,
  enableCheckboxSelection = false,
  emptyState,
  detailPanel,
}: GenericTableTanstackProps<T>) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const loadMoreRef = React.useRef<HTMLDivElement | null>(null);

  const handleRowClick = (row: Row<T>) => {
    onSelectRow?.(row.original);

    if (enableCheckboxSelection) {
      row.toggleSelected();
    }
  };

  /* =========================================================
   ROW SELECTION
   ========================================================= */

  const [rowSelection, setRowSelection] = React.useState<RowSelectionState>({});

  React.useEffect(() => {
    setRowSelection({});
  }, [resetSelectionTrigger]);

  /* =========================================================
   CHECKBOX COLUMN
   ========================================================= */

  const checkboxColumn: ColumnDef<T> = {
    id: "select",
    size: 52,

    header: ({ table }) => (
      <Checkbox
        size="small"
        sx={{ p: 0.3 }}
        checked={table.getIsAllRowsSelected()}
        indeterminate={table.getIsSomeRowsSelected()}
        onChange={table.getToggleAllRowsSelectedHandler()}
      />
    ),

    cell: ({ row }) => (
      <Checkbox
        size="small"
        sx={{ p: 0.3 }}
        checked={row.getIsSelected()}
        disabled={!row.getCanSelect()}
        onChange={row.getToggleSelectedHandler()}
        onClick={(e) => e.stopPropagation()}
      />
    ),
  };

  /* =========================================================
   FINAL COLUMNS
   ========================================================= */

  const expandColumn: ColumnDef<T> = {
    id: "expand",
    header: "",
    size: 40,
    enableSorting: false,

    cell: ({ row }) =>
      expandedRows.has(row.original.id) ? (
        <KeyboardArrowDown fontSize="small" />
      ) : (
        <KeyboardArrowRight fontSize="small" />
      ),
  };

  const finalColumns = [
    ...(detailPanel ? [expandColumn] : []),
    ...(enableCheckboxSelection ? [checkboxColumn] : []),
    ...columns,
  ];

  /* =========================================================
   TABLE
   ========================================================= */

  const table = useReactTable({
    data,
    columns: finalColumns,

    state: {
      sorting,
      rowSelection,
    },

    enableRowSelection: true,

    onRowSelectionChange: setRowSelection,

    manualSorting: true,

    onSortingChange: (updater) => {
      const nextSorting = typeof updater === "function" ? updater(sorting) : updater;

      onSortingChange?.(nextSorting);
    },

    getCoreRowModel: getCoreRowModel(),
  });

  /* =========================================================
   ROW SELECTION EFFECT
   ========================================================= */

  React.useEffect(() => {
    if (!onRowSelectionChange) return;

    const selectedRows = table.getSelectedRowModel().rows.map((r) => r.original);

    onRowSelectionChange(selectedRows);
  }, [rowSelection, table, onRowSelectionChange]);

  const [expandedRows, setExpandedRows] = React.useState<Set<number>>(new Set());

  const toggleExpanded = (id: number) => {
    setExpandedRows((prev) => {
      const next = new Set(prev);

      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }

      return next;
    });
  };

  /* =========================================================
     HEIGHT
     ========================================================= */

const tableHeight = height ?? (isMobile ? undefined : 650);

  /* =========================================================
     INFINITE SCROLL
     ========================================================= */

  React.useEffect(() => {
    if (!hasMore) return;

    if (!onLoadMore) return;

    const el = loadMoreRef.current;

    if (!el) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const first = entries[0];

        if (first.isIntersecting && !loading) {
          onLoadMore();
        }
      },
      {
        threshold: 0.5,
      },
    );

    observer.observe(el);

    return () => {
      observer.disconnect();
    };
  }, [hasMore, loading, onLoadMore]);

  /* =========================================================
     RENDER
     ========================================================= */

  return (
    <Paper
      sx={{
        width: "100%",
        overflow: "hidden",
      }}
    >
      <TableContainer
        sx={{
          maxHeight: tableHeight,
          height: "auto",
          overflowX: "auto",
        }}
      >
        {/* =====================================================
           MOBILE
           ===================================================== */}

        {isMobile && mobileRenderRow ? (
          <Box>
            {table.getRowModel().rows.map((row) => {
              const selected = row.original.id === selectedRowId;

              return (
                <Paper
                  key={row.id}
                  variant="outlined"
                  onClick={() => handleRowClick(row)}
                  sx={{
                    p: 1.2,
                    mb: 1,

                    cursor: "pointer",

                    borderColor: selected ? "primary.main" : "divider",

                    bgcolor: selected ? "action.selected" : undefined,
                  }}
                >
                  <Box display="flex" alignItems="center" gap={1}>
                    {/* =========================
                MOBILE CHECKBOX
               ========================= */}

                    {enableCheckboxSelection && (
                      <Checkbox
                        size="small"
                        checked={row.getIsSelected()}
                        disabled={!row.getCanSelect()}
                        onChange={row.getToggleSelectedHandler()}
                        onClick={(e) => e.stopPropagation()}
                        sx={{
                          p: 0.3,
                          alignSelf: "flex-start",
                          mt: 0.2,
                        }}
                      />
                    )}

                    {/* =========================
                MOBILE CONTENT
               ========================= */}

                    <Box flex={1}>{mobileRenderRow(row.original)}</Box>
                  </Box>
                </Paper>
              );
            })}
          </Box>
        ) : (
          /* ===================================================
             DESKTOP
             =================================================== */
          <Table
            stickyHeader
            size="small"
            sx={{
              tableLayout: fixedColumnWidths ? "fixed" : "auto",
              ...(fixedColumnWidths ? { minWidth: table.getTotalSize() } : { width: "100%" }),
            }}
          >
            <TableHead>
              {table.getHeaderGroups().map((headerGroup) => (
                <TableRow key={headerGroup.id}>
                  {headerGroup.headers.map((header) => {
                    const sorted = header.column.getIsSorted();

                    return (
                      <TableCell
                        key={header.id}
                        align={
                          (header.column.columnDef.meta as { align?: string })?.align === "right"
                            ? "right"
                            : header.id === "select"
                              ? "center"
                              : "left"
                        }
                        onClick={header.column.getToggleSortingHandler()}
                        padding="normal"
                        sx={{
                          ...(fixedColumnWidths && {
                            width: header.getSize(),
                            minWidth: header.getSize(),
                            maxWidth: header.getSize(),
                          }),

                          whiteSpace: "nowrap",

                          overflow: "hidden",
                          textOverflow: "ellipsis",

                          cursor: header.column.getCanSort() ? "pointer" : "default",

                          py: 0.5,
                          px: 1,

                          fontWeight: 700,

                          fontSize: {
                            xs: "0.9rem",
                            md: "1.2rem",
                          },

                          userSelect: "none",
                        }}
                      >
                        <Box
                          display="flex"
                          alignItems="center"
                          justifyContent={
                            (
                              header.column.columnDef.meta as {
                                align?: string;
                              }
                            )?.align === "right"
                              ? "flex-end"
                              : "flex-start"
                          }
                          gap={1}
                        >
                          {flexRender(header.column.columnDef.header, header.getContext())}

                          {sorted === "asc" ? "▲" : sorted === "desc" ? "▼" : ""}
                        </Box>
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}
            </TableHead>

            <TableBody>
              {table.getRowModel().rows.map((row) => {
                const selected = row.original.id === selectedRowId;

                return (
                  <React.Fragment key={row.id}>
                    <TableRow
                      hover
                      selected={selected}
                      onClick={() => {
                        handleRowClick(row);
                        toggleExpanded(row.original.id);
                      }}
                      sx={{
                        cursor: "pointer",

                        // Geschlossene Zeile leicht grau
                        backgroundColor: expandedRows.has(row.original.id) ? "#cdcdcd" : "#f5f5f5",

                        "&:hover": {
                          backgroundColor: expandedRows.has(row.original.id)
                            ? "#c5c5c5"
                            : "#e8e8e8",
                        },

                        "& td": {
                          py: 0.6,
                        },
                      }}
                    >
                      {row.getVisibleCells().map((cell) => (
                        <TableCell
                          key={cell.id}
                          align={
                            (cell.column.columnDef.meta as { align?: string })?.align === "right"
                              ? "right"
                              : cell.column.id === "select"
                                ? "center"
                                : "left"
                          }
                          size="small"
                          padding="normal"
                          sx={{
                            ...(fixedColumnWidths && {
                              width: cell.column.getSize(),
                              minWidth: cell.column.getSize(),
                              maxWidth: cell.column.getSize(),
                            }),
                            py: 0.5,
                            px: 1,
                            fontSize: {
                              xs: "0.82rem",
                              md: "1.2rem",
                            },
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            whiteSpace: "nowrap",
                            lineHeight: 1.2,
                          }}
                        >
                          {flexRender(cell.column.columnDef.cell, cell.getContext())}
                        </TableCell>
                      ))}
                    </TableRow>

                    {detailPanel && (
                      <TableRow>
                        <TableCell
                          colSpan={row.getVisibleCells().length}
                          sx={{
                            p: 0,
                            border: 0,
                          }}
                        >
                          <Collapse
                            in={expandedRows.has(row.original.id)}
                            timeout="auto"
                            unmountOnExit
                          >
                            <Box p={2}>{detailPanel(row.original)}</Box>
                          </Collapse>
                        </TableCell>
                      </TableRow>
                    )}
                  </React.Fragment>
                );
              })}
            </TableBody>
          </Table>
        )}
      </TableContainer>

      {/* =====================================================
         LOADING
         ===================================================== */}

      {loading && (
        <Box display="flex" justifyContent="center" p={2}>
          <CircularProgress size={24} />
        </Box>
      )}

      {/* =====================================================
          EMPTY
        ===================================================== */}

      {!loading && data.length === 0 && (emptyState ?? <EmptyState />)}

      {/* =====================================================
         INFINITE SCROLL
         ===================================================== */}

      {hasMore && (
        <Box ref={loadMoreRef} display="flex" justifyContent="center" p={2}>
          {loading && <CircularProgress size={24} />}
        </Box>
      )}
    </Paper>
  );
}
