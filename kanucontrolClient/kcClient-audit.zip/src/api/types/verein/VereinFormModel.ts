// src/api/types/VereinFormModel.ts

import { PersonRef } from "@/api/types/person/PersonRef";
import { CountryCode } from "@/api/enums/CountryCode";

export default interface VereinFormModel {
  /** ID – nur bei READ / EDIT */
  id?: number;

  /** Pflichtfelder (Backend: @NotNull) */
  name: string;
  abk: string;

  /** Adresse */
  strasse?: string;
  plz?: string;
  ort?: string;
  countryCode: CountryCode;

  /** Kontakt */
  telefon?: string;

  /** Bankdaten */
  bankName?: string;
  iban?: string;
  bic?: string;
  schutzkonzept?: string; // ISO Date

  kikZertifiziertSeit?: string;

  kikZertifiziertBis?: string;

  /** 🔗 Kontoinhaber (Person) */
  kontoinhaber?: PersonRef;

  mitgliederCount?: number;
}
