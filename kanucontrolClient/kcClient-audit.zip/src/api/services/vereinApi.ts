import apiClient from "@/api/client/apiClient";
import Verein from "@/api/types/verein/VereinFormModel";
import { VereinSave } from "@/api/types/verein/VereinSave";
import { VereinRef } from "@/api/types/verein/VereinRef";

const BASE = "/verein";

export const getAllVereine = async (): Promise<Verein[]> => {
  const { data } = await apiClient.get<Verein[]>(BASE);
  return data;
};

export const createVerein = async (verein: VereinSave): Promise<Verein> => {
  const { data } = await apiClient.post<Verein>(BASE, verein);
  return data;
};

export const updateVerein = async (id: number, payload: VereinSave): Promise<Verein> => {
  const { data } = await apiClient.put<Verein>(`${BASE}/${id}`, payload);
  return data;
};

export const deleteVerein = async (vereinId: number): Promise<void> => {
  await apiClient.delete(`${BASE}/${vereinId}`);
};

export async function searchVereine(params: {
  search?: string;
}): Promise<VereinRef[]> {
  const { data } = await apiClient.get<VereinRef[]>("/verein/search/ref", {
    params: {
      search: params.search,
    },
  });

  return data;
}

